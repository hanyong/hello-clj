(ns clj-fun.ttsend
  "Send tt message"
  (:import [com.taobao.timetunnel.client SessionFactory
            TimeTunnelSessionFactory MessageConsumer Message])
  (:import [com.taobao.timetunnel.client.conf ProducerConfig
            ConsumerConfig TimeTunnelConfig]))

(def conf {:topic "ershu_test"
           :router "dwbasis130013.sqa.cm4.tbsite.net:9090"
           :user "ershu"
           :pass "hello1234"
           :subid "ershu_sub"})

(defn make-tt-producer
  "Create a time tunnel consumer"
  [{:keys [topic router user pass]}]
  (let [tt-conf (doto (TimeTunnelConfig. topic)
                  (.setRouterURL router)
                  (.setUser user)
                  (.setPassword pass))
        producer-conf (ProducerConfig. tt-conf)]
    (.createProducer (TimeTunnelSessionFactory/getInstance) producer-conf)))


(defn send-msg
  "Send a tt message"
  [cli data]
  (.send cli (Message. (.getBytes (str data)))))
