(ns clj-fun.fn)

;; create function with comp
(def fifth (comp first rest rest rest rest))
(fifth [1 2 3 4 5])

(defn fnth
  [n]
  (apply comp
         (cons first
               (take (dec n) (repeat rest)))))

((fnth 5) [1 2 3 4 5])


;; closure

(defn create-tax
  [rate]
  (fn [income]
    (* income rate)))

(def cn-tax (create-tax 0.2))

(def us-tax (create-tax 0.15))
