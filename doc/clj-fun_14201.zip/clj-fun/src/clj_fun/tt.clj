(ns clj-fun.tt
  "Using TimeTunnel client in clojure."
  (:import [com.taobao.timetunnel.client SessionFactory
            TimeTunnelSessionFactory MessageConsumer Message])
  (:import [com.taobao.timetunnel.client.conf ProducerConfig
            ConsumerConfig TimeTunnelConfig]))

;;(set! *warn-on-reflection* true)

(def conf {:topic "ershu_test"
           :router "dwbasis130013.sqa.cm4.tbsite.net:9090"
           :user "ershu"
           :pass "hello1234"
           :subid "ershu_sub"})

(defn make-tt-consumer
  "Create a time tunnel consumer"
  [{:keys [topic router user pass subid]}]
  (println "Make a tt consumer")
  (let [tt-conf (doto (TimeTunnelConfig. topic)
                  (.setRouterURL router)
                  (.setUser user)
                  (.setPassword pass))
        consumer-conf (doto (ConsumerConfig. tt-conf)
                        (.setSubscriberId subid))]
    (.createConsumer (TimeTunnelSessionFactory/getInstance) consumer-conf)))

(defn message-seq
  "Create a message lazy-seq"
  [consumer]
  (lazy-seq
   (concat (iterator-seq (.iterator consumer)) (message-seq consumer))))

(defn msg-handler
  "Handle every message"
  [msg]
  (if (or (nil? msg) (nil? (.getData msg)))
    (println "Nil message.")
    (println "Message: " (String. (.getData msg)))))

(defn -main
  "The main"
  [& args]
  (println "...... Start program.")
  (doseq [msg (message-seq (make-tt-consumer conf))]
    (msg-handler msg)))
