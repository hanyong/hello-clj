(ns clj-fun.protocol
  "Sample of protocol")


(defprotocol Concatenatable
  (cat [this other]))

(extend-type String
  Concatenatable
  (cat [this other]
    (.concat this other)))

(cat "House" " of Leaves")

(extend-type java.util.List
  Concatenatable
  (cat [this other]
    (concat this other)))


(cat [1 2 3] [4 5 6])


(defn mk-bad-guy
  "Reify the Concatenable protocal, with a tail."
  [t]
  (reify Concatenatable
    (cat [this other]
      (str "I concat nothing! I am " t))))

(cat (mk-bad-guy "1") (mk-bad-guy "2"))

;; reify a interface see stom nimbus timecache map
;; /Users/xiafei/workspace/storm/src/clj/backtype/storm/daemon/nimbus.clj
