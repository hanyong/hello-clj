;;
;; Swapping Variables
;;
(let [x 6
      y 5
      [x y] [y x]]
  (print x y))

;; 5 6
;; nil



;;
;; Inline if statment
;;
(if true (print "Hello") (print "World"))
;; Hello
;; nil

;;
;; Concatenations
;;
(def nfc ["Packers", "49ers"])
(def afc ["Ravens", "Patriots"])

(concat nfc afc)
;; ("Packers" "49ers" "Ravens" "Patriots")

(conj nfc 1)
;; ["Packers" "49ers" 1]


;;
;; Number Tricks
;;

;;
;; Numerical Comparison
;;

(def x 3)
(when (> 3 x 1)
  print x)

;; other one no so good


;;
;; Iterate Through Two Lists at the Same Time
;;
(def nfc ["Packers", "49ers"])
(def afc ["Ravens", "Patriots"])
(map #(str %1 " v.s. " %2) nfc afc)

;;
;; Iterate Through List With an Index
;;
(def teams ["Packers", "49ers", "Ravens", "Patriots"])
(map-indexed #(str %1 " " %2) teams)

;;
;; List Comprehension
;;
(def numbers [1 2 3 4 5 6])
(filter even? numbers)

;;
;; Dictionary Comprehension
;;
(def teams ["Packers", "49ers", "Ravens", "Patriots"])
(zipmap teams (range))

;;
;; Initialize List Values
;;
(take 3 (repeat 0))

;;
;; Converting a List to a String
;;
(def teams ["Packers", "49ers", "Ravens", "Patriots"])
(clojure.string/join "," teams)


;;
;; Get Item From Dictionary
;;
(def data {"user" 1 "name" "Max" "three" 4})
(data "admin" false)

;;
;; Taking a Subset of a List
;;
(def x [1 2 3 4 5 6])


;;
;; Collections
;;
(frequencies "hello")

;;
;; Itertools
;;
(def teams ["Packers", "49ers", "Ravens", "Patriots"])
(for [x teams
      y teams
      :while (not= x y)]
  [y x])
;; (["Packers" "49ers"] ["Packers" "Ravens"] ["49ers" "Ravens"] ["Packers" "Patriots"] ["49ers" "Patriots"] ["Ravens" "Patriots"])

;;
;; False == True
;;
=.=!!!
