(ns clj-fun.oo
  "example of oo")

(defmulti cnt-fee :referrer)

(defmethod cnt-fee :baidu [pv]
  (* 0.3 (:page-val pv)))

(defmethod cnt-fee :google [pv]
  (* 0.8 (:page-val pv)))

(cnt-fee {:referrer :baidu :page-val 10})
(cnt-fee {:referrer :google :page-val 10})
