(ns clj-fun.macro
  "macro samples")


(defmacro reverse-eval [expr]
  (reverse expr))

(reverse-eval (1 2 3 +))

(defmacro infix [expr]
  (let [a (first expr)
        b (last expr)
        op (second expr)]
    (list op a b)))



;;(deftryfn name [a b] () ())

(defmacro deftryfn [n args & body]
  `(defn ~n ~args
     (try
       ~@body
       (catch Exception e#
         (.getMessage e#))
       (finally
         (println "Finally")))))


(defmacro randomly [& exprs]
  (let [len (count exprs)
        index (rand-int len)
        conditions (map #(list = index %) (range len))]
    `(cond ~@(interleave conditions exprs))))

(randomly (println 1)
          (println 2)
          (println 3))


(pprint (macroexpand '(randomly (println 1) (println 2))))
