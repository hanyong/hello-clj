(ns clj-fun.core)

(defn foo
  "I don't do a whole lot."
  [x]
  (println x "Hello, World!"))

(def my-plus
  (fn [x y] (+ x y)))

(defn my-plus
  "doc-string"
  [x y]
  (- x y)
  (+ x y))

(defn sum-all
  "[x, y)"
  [x y]
  (loop [now x result 0]
    (if (< now y)
      (recur (inc now) (+ result now))
      result)))
