# Introduction to clj-fun

TODO: write [great documentation](http://jacobian.org/writing/great-documentation/what-to-write/)
