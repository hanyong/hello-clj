(defproject clj-fun "0.1.0-SNAPSHOT"
  :description "FIXME: write description"
  :url "http://example.com/FIXME"
  :license {:name "Eclipse Public License"
            :url "http://www.eclipse.org/legal/epl-v10.html"}
  :warn-on-reflection true
  :main clj-fun.tt
  :repositories [["ali maven" "http://mvnrepo.taobao.ali.com/mvn/repository"]]
  ;;:repositories [["nexus.clojure.cn" "http://nexus.clojure.cn/nexus/content/groups/public/"]]
  :dependencies [[org.clojure/clojure "1.4.0"]
                 [com.taobao/timetunnel-client "0.4.0-SNAPSHOT"]])
